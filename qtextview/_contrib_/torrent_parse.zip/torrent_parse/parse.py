#!/usr/bin/env python

import sys
from torrent_parse import torrent_parser, torrent_info

if len(sys.argv) < 2 or (len(sys.argv) == 2 and sys.argv[1] == '--help'):
    print "Usage: %s [list of torrent files]" % sys.argv[0]
    exit(0)

for file in sys.argv[1:] :
    try :
        info = torrent_parser().parse(file)
        print "--- File: %s ---" % file
        print "Created  :", info['creation_time']
        print "Client   :", info.client
        print "Tracker  :", info.tracker
        print "Trackers :", info.trackers
        print "Dir name :", info.dir_name
        print "Files    :", info.files
        print ""
        
    except Exception as ex:
        print "ERROR:", ex

