#!/usr/bin/env python

class UnexpectedSymbolException(Exception) :
    """
    Raised when an unexpected symbol is met while parsing the file.
    
    Attributes:
        position -- position withing the file where an unexpected symbol was met (int)
        symbol   -- the symbol (string)
    """
    
    def __init__(self, position, symbol):
        self.position = position
        self.symbol = symbol
    
    def __str__(self) :
        return "Unexpected symbol '%s' at position %i" % (self.symbol, self.position)


class torrent_info :
    """
    Contains a torrent file information
    
    Attributes:
        creation_time   -- creation time of the torrent in standard UNIX format (int)
        client          -- client used to create the torrent (str)
        tracker         -- announce URL of the tracker (str)
        trackers        -- list of available tracker URLs (list)
        dir_name        -- name of the main directory of the torrent (str)
        files           -- list of files of the torrent. Each list item is a
                            dict of the following structure:
                            {
                                'size' : 1234567,
                                'md5sum' : '595f44fec1e92a71d3e9e77456ba80d1',
                                'path' : [ '01', 'example', 'file.txt' ]
                            }
                            where the 'path' value is a list containing parts of the
                            file's path. The example given above represents the file
                            'file.txt' located in the directory '01/example/' within
                            the torrent.
                            
    """
    
    def __init__(self) :
        self.creation_time = None
        self.client = None
        self.tracker = ''
        self.trackers = []
        self.dir_name = ''
        self.files = []
    
    def __getitem__(self, key) :
        return self.__dict__[key]


class torrent_parser:
    """
    Parses torrent files.
    
    Example of usage:
        
        #!/usr/bin/env python
        from torrent_parse import torrent_parser, torrent_info
        
        info = torrent_parser().parse("some_torrent_file.torrent")
        print info.creation_time, info.client, info.tracker
        # also can be treated as a dict:
        print info['creation_time'], info['client'], info['tracker']
    
    """
    
    def __init__(self) :
        self.__file = None
        self.__pos = 0
    
    """
    Parse a torrent file and return a torrent_info object.
    
    Arguments:
        file_name -- the name of a torrent file to parse.
        
    Return:
        An object of torrent_info class.
    """
    def parse(self, file_name) :
        self.__file = open(file_name, 'rb')
        
        try :
            info = self.__parse_file()
        except Exception as e :
            self.__file.close()
            raise e
        
        return info
    
    
    
    def __parse_file(self) :
        # read data
        data = self.__read_token()
        
        # create and populate the returning object
        torr_info = torrent_info()
        torr_info.creation_time  = data.get('creation date', None)
        torr_info.client         = data.get('created by', '')
        torr_info.tracker        = data.get('announce', '')
        
        # trackers
        for item in data.get('announce-list', []) :
            if isinstance(item, list) :
                torr_info.trackers += item
            else :
                torr_info.trackers.append(item)
        
        # file info
        file_info = data.get('info', {})
        
        if file_info.get('length') != None :
            # single-file format
            path = [file_info.get('name', '')]
            size = file_info.get('length', 0)
            md5sum = file_info.get('md5sum', '')
            torr_info.files.append( {'path' : path, 'size' : size, 'md5sum' : md5sum } )
        else :
            # multi-file format
            torr_info.dir_name = file_info.get('name', '')
            for file_data in file_info.get('files', []) :
                path = file_data.get('path', [])
                size = file_data.get('length', 0)
                md5sum = file_info.get('md5sum', '')
                torr_info.files.append( {'path' : path, 'size' : size, 'md5sum' : md5sum } )
        
        return torr_info
    
    # cached list of numeric symbols
    __digits = [ str(i) for i in xrange(0, 10) ]
    
    def __read_token(self) :
        token_type = self.__read_chunk()
        if token_type in ['', 'e'] :
            return None
        
        if token_type == 'd' :
            return self.__read_dict()
        elif token_type == 'l' :
            return self.__read_list()
        elif token_type == 'i' :
            return self.__read_int()
        elif token_type in torrent_parser.__digits :
            # start collecting digits
            length_str = token_type
            
            # read length
            symbol = self.__read_chunk()
            while symbol in torrent_parser.__digits :
                length_str += symbol
                symbol = self.__read_chunk()
            
            # check if we stopped at ':'
            if symbol != ':' :
                raise UnexpectedSymbolException(self.__pos, symbol)
            
            length = int(length_str)
            value = self.__read_chunk(length)
            self.__pos += len(value)

            return value
        else :
            raise UnexpectedSymbolException(self.__pos, token_type)
        return None
    
    def __read_dict(self) :
        result_dict = dict()
        
        while True :
            key = self.__read_token()
            if key == None :
                break
            value = self.__read_token()
            result_dict[key] = value
            
        return result_dict
    
    def __read_list(self) :
        result_list = []
        while True :
            item = self.__read_token()
            if item == None :
                break
            result_list.append(item)
        
        return result_list
    
    def __read_int(self) :
        value_str = ''
        
        # read digits
        symbol = self.__read_chunk()
        while symbol in torrent_parser.__digits :
            value_str += symbol
            symbol = self.__read_chunk()
        
        # check if we stopped at 'e'
        if symbol != 'e' :
            raise UnexpectedSymbolException(self.__pos, symbol)
        
        return int(value_str)
    
    def __read_chunk(self, size=1) :
        chunk = self.__file.read(size)
        if ( chunk != '' ) :
            self.__pos += len(chunk)
        return chunk
