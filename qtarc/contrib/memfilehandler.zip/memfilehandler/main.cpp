#include "memfilesystem.h"
#include <QtGui>

int main(int argc, char **argv){
    QApplication app(argc, argv);
    MemFileSystem memfs;
    QFile f(argv[1]);
    if(!f.open(QFile::ReadOnly)){
        qDebug() << "OPEN FAILED";
    } else { qDebug() <<"Open ok"; }
    QByteArray ba = f.readAll();
    qDebug() << "RAW: " << ba.size();
    qDebug("File read");
    memfs.addFile("tux.jpg", ba);
    QLabel l;
    QFile ff("mem:tux.jpg");
    ff.open(QFile::ReadOnly);
    qDebug() << "MEM:" << ff.readAll().size();
    l.setPixmap(QPixmap("mem:tux.jpg"));
    l.show();
    return app.exec();
}

