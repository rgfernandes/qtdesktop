#ifndef MEMFILESYSTEM_H
#define MEMFILESYSTEM_H

#include <QAbstractFileEngineHandler>
#include <QByteArray>
#include <QHash>
#include <QString>

class MemFileSystem : public QAbstractFileEngineHandler
{
public:
    MemFileSystem();
    QAbstractFileEngine * create ( const QString & fileName ) const;
    void addFile(const QString &filePath, const QByteArray &ba);
private:
    QHash<QString,QByteArray> m_files;
};

#endif // MEMFILESYSTEM_H
