#include "memfilesystem.h"
#include "memfilehandler.h"

MemFileSystem::MemFileSystem()
{
}

QAbstractFileEngine * MemFileSystem::create ( const QString & fileName ) const {
    if(!fileName.startsWith("mem:")) return 0;
    return new MemFileHandler(m_files.value(fileName.mid(4), QByteArray()));
}

void MemFileSystem::addFile(const QString &filePath, const QByteArray &ba) {
    m_files[filePath] = ba;
}
