#ifndef QTZIP_GLOBAL_H
#define QTZIP_GLOBAL_H

#include <QtCore/qglobal.h>



#endif // QTZIP_GLOBAL_H
